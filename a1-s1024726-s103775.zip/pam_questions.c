#define PM_SM_AUTH

#include <security/pam_appl.h>
#include <security/pam_modules.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>


int pam_sm_open_session(pam_handle_t *pamh, int flags, int argc, const char **argv) {
	return(PAM_IGNORE);
}

int pam_sm_close_session(pam_handle_t *pamh, int flags, int argc, const char **argv) {
	return(PAM_IGNORE);
}


int pam_sm_acct_mgmt(pam_handle_t *pamh, int flags, int argc, const char **argv) {
	return(PAM_IGNORE);
}

int pam_sm_authenticate(pam_handle_t *pamh, int flags, int argc, const char **argv){
	const int MAX = 20;
	const char* questions[] = {"Who am i?", "Ice..?", "Coffee or Tea?", "What's the biggest joke?", "How do you do?"};
        char* actual_answers[] = {"root", "ice baby", "tea", "brexit", "do what?"};

       	char *answer = (char*) malloc(MAX);
	if(answer == NULL) {
		printf("Memory error. Terminating.. \n");
		return(PAM_PERM_DENIED);
	}

	srand(time(NULL));	
	int r = rand() % 5;

	printf("Question: %s\n", questions[r]);
	char* solution = actual_answers[r];

	fgets(answer, MAX, stdin);
	if(strncmp(answer, solution, strlen(solution)) == 0)
	{
		return(PAM_SUCCESS);
	}	
	return(PAM_AUTH_ERR);
}

int pam_sm_setcred(pam_handle_t *pamh, int flags, int argc, const char **argv) {
	return(PAM_IGNORE);
}

int pam_sm_chauthtok(pam_handle_t *pamh, int flags, int argc, const char **argv) {
	return(PAM_IGNORE);
  }
